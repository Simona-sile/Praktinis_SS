import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.open;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class Test1 {
    String webAppUrl = "https://demo.opencart.com/index.php?route=common/home";

    @BeforeEach
    void startTest() {
        /** Screenshot after each tests is disabled */
        Configuration.screenshots = false;
/** Tests runs in the background */
        Configuration.headless = false;
/** Leaves browser open when test is finished */
        Configuration.holdBrowserOpen = true;
/** Opens web app */
        open(webAppUrl);
    }
    @Test
    void LaptopsandNotebooks(){
        Selenide.$(".dropdown-toggle[href='https://demo.opencart.com/index.php?route=product/category&path=18']").click();
        $("li[class='dropdown open'] a[class='see-all']").click();
        $("img[title='HP LP3065']").click();
        assertEquals("Availability: In Stock", "div[id='product-product'] li:nth-child(4)", "Fail");
        Selenide.back();
        $("img[title='MacBook']").click();
        assertEquals("Availability: In Stock", "div[class='col-sm-4'] li:nth-child(4)", "Out of stock");
        Selenide.back();
        $("img[title='MacBook Air']").click();
        assertEquals("Availability: In Stock", "div[class='col-sm-4'] li:nth-child(4)", "Out Of stock");
        Selenide.back();
        $("img[title='MacBook Pro']").click();
        assertEquals("Availability: In Stock", "div[class='col-sm-4'] li:nth-child(4)", "Out Of stock");
        $("img[title='Sony VAIO']").click();
        assertEquals("Availability: In Stock", "div[class='col-sm-4'] li:nth-child(4)", "Out Of stock");
    }
    @Test
    void Tablets(){
        Selenide.$("//a[normalize-space()='Tablets']").click();
        $("img[title='Samsung Galaxy Tab 10.1']").click();
        assertEquals("Availability: In Stock", "div[class='col-sm-4'] li:nth-child(3)", "Pre-Order");
    }
    @Test

    void PhonesandPDA(){
        $("li:nth-child(6) a:nth-child(1)").click();
        $("img[title='HTC Touch HD']").click();
        assertEquals("Availability: In Stock", "div[class='col-sm-4'] li:nth-child(3)", "Out of Stock");
        Selenide.back();
        $("img[title='iPhone']").click();
        assertEquals("Availability: In Stock", "div[class='col-sm-4'] li:nth-child(3)", "Out of Stock");
        Selenide.back();
        $("img[title='Palm Treo Pro']").click();
        assertEquals("Availability: In Stock", "div[class='col-sm-4'] li:nth-child(3)", "2-3 Days");


    }

}
