import com.codeborne.selenide.Selenide;
import org.junit.jupiter.api.Test;

import static com.codeborne.selenide.Selenide.$;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class Test2 {
    @Test
    void Tablets(){
        Selenide.$("//a[normalize-space()='Tablets']").click();
        $("img[title='Samsung Galaxy Tab 10.1']").click();
        assertEquals("Availability: In Stock", "div[class='col-sm-4'] li:nth-child(3)", "Pre-Order");
    }
    @Test
    void Cameras(){
        $("li:nth-child(7) a:nth-child(1)").click();
        $("img[title='Canon EOS 5D']").click();
        assertEquals("Availability: In Stock", "div[id='product-product'] li:nth-child(4)", "2-3 Days");
        Selenide.back();
        $("img[title='Nikon D300']").click();
        assertEquals("Availability: In Stock", "div[id='product-product'] li:nth-child(4)", "2-3 Days");
    }
    @Test
    void MP3Players(){
        $(".dropdown-toggle[href='https://demo.opencart.com/index.php?route=product/category&path=34']").click();
        $("li[class='dropdown open'] a[class='see-all']").click();
        $("img[title='iPod Classic']").click();
        assertEquals("Availability: In Stock", "div[class='col-sm-4'] li:nth-child(3)", "Out of Stock");
        Selenide.back();
        $("img[title='iPod Nano']").click();
        assertEquals("Availability: In Stock", "div[class='col-sm-4'] li:nth-child(3)", "2-3 Days");





    }

}
